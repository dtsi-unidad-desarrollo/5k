<?php $__env->startSection('title', 'Participantes Registrados | Carrera 5K UNELLEZ'); ?>

<?php $__env->startSection('content'); ?>
<div style="max-width: 1040px; margin: 0 auto;">
    <div style="display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 1rem; margin-bottom: 1.5rem;">
        <div>
            <a href="<?php echo e(route('home')); ?>" class="btn btn-outline btn-sm" style="margin-bottom: 0.75rem;">
                <i class="fa-solid fa-arrow-left"></i> Volver al Formulario
            </a>
            <h1 style="font-size: 1.85rem; font-weight: 800; line-height: 1.2;">
                Listado de Corredores Inscritos
            </h1>
            <p style="color: var(--text-muted); font-size: 0.9rem;">
                Total de participantes registrados oficialmente: <strong style="color: var(--accent-gold);"><?php echo e($totalCount); ?></strong>
            </p>
        </div>

        <div style="display: flex; gap: 0.75rem;">
            <a href="<?php echo e(route('participants.export')); ?>" class="btn btn-gold btn-sm">
                <i class="fa-solid fa-file-csv"></i> Descargar CSV Oficial
            </a>
            <button onclick="window.print()" class="btn btn-outline btn-sm">
                <i class="fa-solid fa-print"></i> Imprimir Roster
            </button>
        </div>
    </div>

    <!-- Search Bar -->
    <div style="background: var(--surface-card); border: 1px solid var(--surface-border); border-radius: var(--radius-md); padding: 1rem; margin-bottom: 1.5rem;">
        <form action="<?php echo e(route('participants.list')); ?>" method="GET" style="display: flex; gap: 0.75rem;">
            <input type="text" 
                   name="q" 
                   value="<?php echo e($search); ?>" 
                   class="form-input" 
                   placeholder="Buscar por cédula, nombre, apellido o número (Ej: 5K-0001)...">
            <button type="submit" class="btn btn-primary" style="white-space: nowrap;">
                <i class="fa-solid fa-magnifying-glass"></i> Buscar
            </button>
            <?php if($search): ?>
                <a href="<?php echo e(route('participants.list')); ?>" class="btn btn-outline" style="white-space: nowrap;">
                    Limpiar
                </a>
            <?php endif; ?>
        </form>
    </div>

    <!-- Participants Table -->
    <div class="table-responsive">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>Dorsal</th>
                    <th>Corredor</th>
                    <th>Cédula</th>
                    <th>Teléfono</th>
                    <th>Fecha Registro</th>
                    <th style="text-align: right;">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <span class="bib-pill-small"><?php echo e($p->bib_number); ?></span>
                        </td>
                        <td style="font-weight: 700; color: white;">
                            <?php echo e($p->full_name); ?>

                        </td>
                        <td style="font-family: var(--font-mono);">
                            <?php echo e($p->national_id); ?>

                        </td>
                        <td>
                            <?php echo e($p->phone); ?>

                        </td>
                        <td style="color: var(--text-muted); font-size: 0.85rem;">
                            <?php echo e($p->created_at->format('d/m/Y H:i')); ?>

                        </td>
                        <td style="text-align: right;">
                            <a href="<?php echo e(route('participants.bib', $p->bib_number)); ?>" class="btn btn-outline btn-sm" target="_blank" title="Ver dorsal e imprimir">
                                <i class="fa-solid fa-print"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 3rem 1rem; color: var(--text-muted);">
                            <i class="fa-solid fa-user-slash" style="font-size: 2rem; margin-bottom: 0.5rem; display: block;"></i>
                            No se encontraron participantes registrados con los criterios especificados.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div style="margin-top: 1.5rem;">
        <?php echo e($participants->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Jesus\.gemini\antigravity-ide\scratch\carrera5k-unellez\resources\views/participants/list.blade.php ENDPATH**/ ?>